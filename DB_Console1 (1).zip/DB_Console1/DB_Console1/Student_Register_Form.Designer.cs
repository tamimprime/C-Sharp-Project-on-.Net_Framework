﻿
namespace DB_Console1
{
    partial class Student_Register_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_confirm = new System.Windows.Forms.Button();
            this.tb_credit = new System.Windows.Forms.TextBox();
            this.tb_uname = new System.Windows.Forms.TextBox();
            this.tb_sec = new System.Windows.Forms.TextBox();
            this.section = new System.Windows.Forms.Label();
            this.dept = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.Label();
            this.tb_dept = new System.Windows.Forms.TextBox();
            this.credit = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.cgpa = new System.Windows.Forms.Label();
            this.tb_pass = new System.Windows.Forms.TextBox();
            this.pass = new System.Windows.Forms.Label();
            this.tb_cgpa = new System.Windows.Forms.TextBox();
            this.uname = new System.Windows.Forms.Label();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.bt_login = new System.Windows.Forms.Button();
            this.tb_registration = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_confirm
            // 
            this.bt_confirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_confirm.Location = new System.Drawing.Point(153, 353);
            this.bt_confirm.Name = "bt_confirm";
            this.bt_confirm.Size = new System.Drawing.Size(136, 49);
            this.bt_confirm.TabIndex = 113;
            this.bt_confirm.Text = "Confirm";
            this.bt_confirm.UseVisualStyleBackColor = true;
            this.bt_confirm.Click += new System.EventHandler(this.Open_Confirm_Click);
            // 
            // tb_credit
            // 
            this.tb_credit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_credit.Location = new System.Drawing.Point(153, 243);
            this.tb_credit.Name = "tb_credit";
            this.tb_credit.Size = new System.Drawing.Size(357, 26);
            this.tb_credit.TabIndex = 112;
            // 
            // tb_uname
            // 
            this.tb_uname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_uname.Location = new System.Drawing.Point(153, 275);
            this.tb_uname.Name = "tb_uname";
            this.tb_uname.Size = new System.Drawing.Size(357, 26);
            this.tb_uname.TabIndex = 111;
            // 
            // tb_sec
            // 
            this.tb_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_sec.Location = new System.Drawing.Point(153, 179);
            this.tb_sec.Name = "tb_sec";
            this.tb_sec.Size = new System.Drawing.Size(357, 26);
            this.tb_sec.TabIndex = 110;
            // 
            // section
            // 
            this.section.AutoSize = true;
            this.section.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.section.Location = new System.Drawing.Point(76, 182);
            this.section.Name = "section";
            this.section.Size = new System.Drawing.Size(67, 20);
            this.section.TabIndex = 109;
            this.section.Text = "Section:";
            // 
            // dept
            // 
            this.dept.AutoSize = true;
            this.dept.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dept.Location = new System.Drawing.Point(95, 150);
            this.dept.Name = "dept";
            this.dept.Size = new System.Drawing.Size(48, 20);
            this.dept.TabIndex = 108;
            this.dept.Text = "Dept:";
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id.Location = new System.Drawing.Point(116, 86);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(27, 20);
            this.id.TabIndex = 107;
            this.id.Text = "Id:";
            // 
            // tb_dept
            // 
            this.tb_dept.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_dept.Location = new System.Drawing.Point(153, 147);
            this.tb_dept.Name = "tb_dept";
            this.tb_dept.Size = new System.Drawing.Size(357, 26);
            this.tb_dept.TabIndex = 106;
            // 
            // credit
            // 
            this.credit.AutoSize = true;
            this.credit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.credit.Location = new System.Drawing.Point(88, 246);
            this.credit.Name = "credit";
            this.credit.Size = new System.Drawing.Size(55, 20);
            this.credit.TabIndex = 105;
            this.credit.Text = "Credit:";
            // 
            // tb_name
            // 
            this.tb_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_name.Location = new System.Drawing.Point(153, 115);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(357, 26);
            this.tb_name.TabIndex = 104;
            // 
            // cgpa
            // 
            this.cgpa.AutoSize = true;
            this.cgpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cgpa.Location = new System.Drawing.Point(85, 214);
            this.cgpa.Name = "cgpa";
            this.cgpa.Size = new System.Drawing.Size(58, 20);
            this.cgpa.TabIndex = 103;
            this.cgpa.Text = "CGPA:";
            // 
            // tb_pass
            // 
            this.tb_pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_pass.Location = new System.Drawing.Point(153, 307);
            this.tb_pass.Name = "tb_pass";
            this.tb_pass.Size = new System.Drawing.Size(357, 26);
            this.tb_pass.TabIndex = 102;
            // 
            // pass
            // 
            this.pass.AutoSize = true;
            this.pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass.Location = new System.Drawing.Point(61, 310);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(82, 20);
            this.pass.TabIndex = 101;
            this.pass.Text = "Password:";
            // 
            // tb_cgpa
            // 
            this.tb_cgpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_cgpa.Location = new System.Drawing.Point(153, 211);
            this.tb_cgpa.Name = "tb_cgpa";
            this.tb_cgpa.Size = new System.Drawing.Size(357, 26);
            this.tb_cgpa.TabIndex = 100;
            // 
            // uname
            // 
            this.uname.AutoSize = true;
            this.uname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uname.Location = new System.Drawing.Point(56, 278);
            this.uname.Name = "uname";
            this.uname.Size = new System.Drawing.Size(87, 20);
            this.uname.TabIndex = 99;
            this.uname.Text = "Username:";
            // 
            // tb_id
            // 
            this.tb_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_id.Location = new System.Drawing.Point(153, 83);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(357, 26);
            this.tb_id.TabIndex = 98;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(88, 118);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(55, 20);
            this.name.TabIndex = 97;
            this.name.Text = "Name:";
            // 
            // bt_login
            // 
            this.bt_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_login.Location = new System.Drawing.Point(374, 353);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(136, 49);
            this.bt_login.TabIndex = 114;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = true;
            this.bt_login.Click += new System.EventHandler(this.Login_Click);
            // 
            // tb_registration
            // 
            this.tb_registration.AutoSize = true;
            this.tb_registration.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tb_registration.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_registration.ForeColor = System.Drawing.Color.Blue;
            this.tb_registration.Location = new System.Drawing.Point(232, 24);
            this.tb_registration.Name = "tb_registration";
            this.tb_registration.Size = new System.Drawing.Size(187, 37);
            this.tb_registration.TabIndex = 115;
            this.tb_registration.Text = "Registration";
            // 
            // Student_Register_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(644, 421);
            this.Controls.Add(this.tb_registration);
            this.Controls.Add(this.bt_login);
            this.Controls.Add(this.bt_confirm);
            this.Controls.Add(this.tb_credit);
            this.Controls.Add(this.tb_uname);
            this.Controls.Add(this.tb_sec);
            this.Controls.Add(this.section);
            this.Controls.Add(this.dept);
            this.Controls.Add(this.id);
            this.Controls.Add(this.tb_dept);
            this.Controls.Add(this.credit);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.cgpa);
            this.Controls.Add(this.tb_pass);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.tb_cgpa);
            this.Controls.Add(this.uname);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.name);
            this.Name = "Student_Register_Form";
            this.Text = "Student_Register_form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_confirm;
        private System.Windows.Forms.TextBox tb_credit;
        private System.Windows.Forms.TextBox tb_uname;
        private System.Windows.Forms.TextBox tb_sec;
        private System.Windows.Forms.Label section;
        private System.Windows.Forms.Label dept;
        private System.Windows.Forms.Label id;
        private System.Windows.Forms.TextBox tb_dept;
        private System.Windows.Forms.Label credit;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Label cgpa;
        private System.Windows.Forms.TextBox tb_pass;
        private System.Windows.Forms.Label pass;
        private System.Windows.Forms.TextBox tb_cgpa;
        private System.Windows.Forms.Label uname;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.Label tb_registration;
    }
}