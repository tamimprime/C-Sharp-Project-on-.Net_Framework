﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access.Entities
{
    public class Student
    {

        public string Id { get; set; }
        public string Name { get; set; }
        public string Dept { get; set; }
        public string Section { get; set; }
        public string Cgpa { get; set; }
        public string Credit { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        






    }
}
